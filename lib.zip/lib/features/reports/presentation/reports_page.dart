import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../../core/providers/analytics_provider.dart';
import '../../../core/providers/expenses_provider.dart';

import 'widgets/add_expense_dialog.dart';

class ReportsPage extends ConsumerWidget {
  const ReportsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sales = ref.watch(totalSalesProvider);

    final cost = ref.watch(totalCostProvider);

    final profit = ref.watch(profitProvider);

    final expenses = ref.watch(totalExpensesProvider);

    final orders = ref.watch(totalOrdersProvider);

    final customers = ref.watch(totalCustomersProvider);

    final products = ref.watch(totalProductsProvider);

    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,

              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    const Text(
                      "Reports & Analysis",

                      style: TextStyle(
                        fontSize: 30,

                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 6),

                    Text(
                      "Business performance overview",

                      style: TextStyle(color: Colors.grey.shade600),
                    ),
                  ],
                ),

                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,

                      vertical: 14,
                    ),

                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),

                  onPressed: () async {
                    await showDialog(
                      context: context,
                      builder: (_) => const AddExpenseDialog(),
                    );

                    ref.invalidate(totalExpensesProvider);
                    ref.invalidate(profitProvider);
                    ref.invalidate(financialSummaryProvider);
                  },

                  icon: const Icon(Icons.add),

                  label: const Text("Add Expense"),
                ),
              ],
            ),

            const SizedBox(height: 30),

            _periodButtons(context, ref),

            const SizedBox(height: 30),

            LayoutBuilder(
              builder: (context, constraints) {
                int count = 4;

                if (constraints.maxWidth < 1100) {
                  count = 2;
                }

                if (constraints.maxWidth < 600) {
                  count = 1;
                }

                return GridView.count(
                  shrinkWrap: true,

                  physics: const NeverScrollableScrollPhysics(),

                  crossAxisCount: count,

                  crossAxisSpacing: 20,

                  mainAxisSpacing: 20,

                  childAspectRatio: 1.6,

                  children: [
                    _statCard("Total Sales", sales, Icons.point_of_sale),

                    _statCard("Total Cost", cost, Icons.shopping_cart),

                    _statCard("Net Profit", profit, Icons.trending_up),

                    _statCard("Expenses", expenses, Icons.money_off),
                    _statIntCard("Total Orders", orders, Icons.receipt_long),

                    _statIntCard("Customers", customers, Icons.people),

                    _statIntCard("Products", products, Icons.inventory),
                  ],
                );
              },
            ),

            const SizedBox(height: 30),

            _salesChart(ref),

            const SizedBox(height: 24),

            _financialChart(ref),

            const SizedBox(height: 24),

            _debtChart(ref),
          ],
        ),
      ),
    );
  }

  Widget _periodButtons(BuildContext context, WidgetRef ref) {
    final now = DateTime.now();
    void setPeriod(DateTime from, DateTime to) {
      ref.read(analyticsPeriodProvider.notifier).state = AnalyticsPeriod(
        from: from,
        to: to,
      );

      Future.microtask(() {
        ref.invalidate(totalSalesProvider);
        ref.invalidate(totalCostProvider);
        ref.invalidate(profitProvider);
        ref.invalidate(totalExpensesProvider);
        ref.invalidate(salesChartProvider);
        ref.invalidate(financialSummaryProvider);
      });
    }

    return Wrap(
      spacing: 10,

      children: [
        _periodButton("Today", () {
          setPeriod(DateTime(now.year, now.month, now.day), now);
        }),

        _periodButton("Week", () {
          final from = DateTime(
            now.year,
            now.month,
            now.day,
          ).subtract(const Duration(days: 7));

          setPeriod(from, now);
        }),

        _periodButton("Month", () {
          setPeriod(DateTime(now.year, now.month, 1), now);
        }),
        _periodButton("Custom", () async {
          final range = await showDateRangePicker(
            context: context,

            firstDate: DateTime(2020),

            lastDate: now,
          );

          if (range == null) return;

          setPeriod(
            DateTime(range.start.year, range.start.month, range.start.day),

            DateTime(
              range.end.year,
              range.end.month,
              range.end.day,
              23,
              59,
              59,
            ),
          );
        }),
      ],
    );
  }

  Widget _periodButton(String text, VoidCallback onPressed) {
    return FilledButton(
      onPressed: onPressed,

      style: FilledButton.styleFrom(
        minimumSize: const Size(100, 42),

        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),

      child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
    );
  }

  Widget _statCard(String title, AsyncValue<double> value, IconData icon) {
    return Card(
      elevation: 1,

      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),

      child: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,

              children: [
                Text(title, style: TextStyle(color: Colors.grey.shade700)),

                Icon(icon),
              ],
            ),

            const Spacer(),

            value.when(
              data: (v) => Text(
                "${v.toStringAsFixed(0)} EGP",

                style: const TextStyle(
                  fontSize: 24,

                  fontWeight: FontWeight.bold,
                ),
              ),

              loading: () => const CircularProgressIndicator(),

              error: (e, _) => Text(e.toString()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _salesChart(WidgetRef ref) {
    final chart = ref.watch(salesChartProvider);

    return Card(
      child: SizedBox(
        height: 320,

        child: Padding(
          padding: const EdgeInsets.all(20),

          child: chart.when(
            data: (data) {
              if (data.isEmpty) {
                return const Center(child: Text("No sales data"));
              }

              return LineChart(
                LineChartData(
                  borderData: FlBorderData(show: false),

                  lineBarsData: [
                    LineChartBarData(
                      spots: data.asMap().entries.map((e) {
                        final total = e.value["total"] ?? 0;

                        return FlSpot(
                          e.key.toDouble(),

                          (total as num).toDouble(),
                        );
                      }).toList(),

                      isCurved: true,

                      barWidth: 4,
                    ),
                  ],
                ),
              );
            },

            loading: () => const Center(child: CircularProgressIndicator()),

            error: (e, _) => Text(e.toString()),
          ),
        ),
      ),
    );
  }

  Widget _financialChart(WidgetRef ref) {
    final summary = ref.watch(financialSummaryProvider);

    return Card(
      child: SizedBox(
        height: 320,

        child: summary.when(
          data: (data) {
            return BarChart(
              BarChartData(
                borderData: FlBorderData(show: false),

                barGroups: [
                  BarChartGroupData(
                    x: 0,

                    barRods: [BarChartRodData(toY: data.sales)],
                  ),

                  BarChartGroupData(
                    x: 1,

                    barRods: [BarChartRodData(toY: data.cost)],
                  ),

                  BarChartGroupData(
                    x: 2,

                    barRods: [BarChartRodData(toY: data.profit)],
                  ),
                ],
              ),
            );
          },

          loading: () => const CircularProgressIndicator(),

          error: (e, _) => Text(e.toString()),
        ),
      ),
    );
  }

  Widget _debtChart(WidgetRef ref) {
    final debt = ref.watch(debtSummaryProvider);

    return Card(
      child: SizedBox(
        height: 320,

        child: debt.when(
          data: (data) {
            final customer = data["Customer Debt"] ?? 0;

            final supplier = data["Supplier Debt"] ?? 0;

            return PieChart(
              PieChartData(
                centerSpaceRadius: 50,

                sections: [
                  PieChartSectionData(
                    value: customer,

                    title: "Customers\n${customer.toStringAsFixed(0)}",

                    radius: 100,
                  ),

                  PieChartSectionData(
                    value: supplier,

                    title: "Suppliers\n${supplier.toStringAsFixed(0)}",

                    radius: 100,
                  ),
                ],
              ),
            );
          },

          loading: () => const CircularProgressIndicator(),

          error: (e, _) => Text(e.toString()),
        ),
      ),
    );
  }

  Widget _statIntCard(String title, AsyncValue<int> value, IconData icon) {
    return Card(
      elevation: 1,

      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),

      child: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,

              children: [
                Text(title, style: TextStyle(color: Colors.grey.shade700)),

                Icon(icon),
              ],
            ),

            const Spacer(),

            value.when(
              data: (v) => Text(
                v.toString(),

                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),

              loading: () => const CircularProgressIndicator(),

              error: (e, _) => Text(e.toString()),
            ),
          ],
        ),
      ),
    );
  }
}
