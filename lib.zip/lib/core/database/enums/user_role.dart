enum UserRole { admin, cashier }
