import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';
import '../../../../app/theme/app_shadows.dart';
import '../../../../app/theme/app_text_styles.dart';

import '../../../../core/providers/analytics_provider.dart';

class SalesChart extends ConsumerWidget {
  const SalesChart({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final chart = ref.watch(salesChartProvider);

    return Container(
      padding: const EdgeInsets.all(24),

      decoration: BoxDecoration(
        color: AppColors.surface,

        borderRadius: BorderRadius.circular(22),

        border: Border.all(color: AppColors.border.withValues(alpha: 0.5)),

        boxShadow: AppShadows.card,
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,

            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [
                  Text("Sales Overview", style: AppTextStyles.h3),

                  const SizedBox(height: 4),

                  Text(
                    "Last 7 days performance",

                    style: AppTextStyles.bodySmall,
                  ),
                ],
              ),

              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,

                  vertical: 8,
                ),

                decoration: BoxDecoration(
                  color: AppColors.primaryLight,

                  borderRadius: BorderRadius.circular(20),
                ),

                child: Text(
                  "Weekly",

                  style: AppTextStyles.bodySmall.copyWith(
                    color: AppColors.primary,

                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 28),

          SizedBox(
            height: 300,

            child: chart.when(
              data: (data) {
                if (data.isEmpty) {
                  return const Center(child: Text("No Sales Data"));
                }

                final spots = data.asMap().entries.map((e) {
                  return FlSpot(
                    e.key.toDouble(),

                    (e.value["total"] as num).toDouble(),
                  );
                }).toList();

                return LineChart(
                  LineChartData(
                    minX: 0,

                    maxX: spots.length.toDouble() - 1,

                    minY: 0,

                    borderData: FlBorderData(show: false),

                    gridData: FlGridData(
                      show: true,

                      drawVerticalLine: false,

                      horizontalInterval: null,

                      getDrawingHorizontalLine: (value) {
                        return FlLine(
                          color: Colors.grey.withValues(alpha: 0.12),

                          strokeWidth: 1,
                        );
                      },
                    ),

                    titlesData: FlTitlesData(
                      topTitles: const AxisTitles(),

                      rightTitles: const AxisTitles(),

                      leftTitles: const AxisTitles(),

                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,

                          reservedSize: 32,

                          getTitlesWidget: (value, meta) {
                            if (value.toInt() >= data.length) {
                              return const SizedBox();
                            }

                            final day = data[value.toInt()]["day"].toString();

                            return Padding(
                              padding: const EdgeInsets.only(top: 8),

                              child: Text(
                                day.length > 5 ? day.substring(5) : day,

                                style: AppTextStyles.caption,
                              ),
                            );
                          },
                        ),
                      ),
                    ),

                    lineTouchData: LineTouchData(
                      touchTooltipData: LineTouchTooltipData(
                        getTooltipItems: (spots) {
                          return spots.map((spot) {
                            return LineTooltipItem(
                              "${spot.y.toStringAsFixed(0)} EGP",

                              const TextStyle(fontWeight: FontWeight.bold),
                            );
                          }).toList();
                        },
                      ),
                    ),

                    lineBarsData: [
                      LineChartBarData(
                        spots: spots,

                        isCurved: true,

                        color: AppColors.primary,

                        barWidth: 4,

                        isStrokeCapRound: true,

                        dotData: const FlDotData(show: false),

                        belowBarData: BarAreaData(
                          show: true,

                          gradient: LinearGradient(
                            colors: [
                              AppColors.primary.withValues(alpha: 0.25),

                              AppColors.primary.withValues(alpha: 0.02),
                            ],

                            begin: Alignment.topCenter,

                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },

              loading: () => const Center(child: CircularProgressIndicator()),

              error: (e, _) => Center(child: Text(e.toString())),
            ),
          ),
        ],
      ),
    );
  }
}
