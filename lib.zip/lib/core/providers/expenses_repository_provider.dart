import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../database/app_database.dart';
import '../database/repositories/expenses_repository.dart';

final expensesRepositoryProvider = Provider<ExpensesRepository>((ref) {
  return ExpensesRepository(AppDatabase());
});

final expensesProvider = StreamProvider<List<Expense>>((ref) {
  final repo = ref.watch(expensesRepositoryProvider);

  return repo.watchAll();
});

final totalExpensesProvider = FutureProvider<double>((ref) {
  final repo = ref.watch(expensesRepositoryProvider);

  return repo.totalExpenses();
});
